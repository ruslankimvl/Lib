﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Model;
namespace Library
{
    class Program
    {
        static void Main(string[] args)
        {
            Libraryy lib = new Libraryy();
            lib.aw();
            //ServiceMenu serviceMenu = new ServiceMenu();
            //Person user = new Person("Ruslan", "Gay", "Kr");
            //int swtc = Int32.Parse(Console.ReadLine());
            //switch (swtc)
            //{
            //    case 1:
            //        serviceMenu.Registration(user);
            //    break;
            //}


        }
    }
}
